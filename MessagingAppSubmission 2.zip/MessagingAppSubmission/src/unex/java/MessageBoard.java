package unex.java;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/* Developer: Colin Ilgen
* Servlet implementation class MessageBoard
 */

@WebServlet("/MessageBoard")
public class MessageBoard extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	private static ArrayList<MessageBean> messages = new ArrayList<>();
	private static String testUsername = "Rich";
	private static String testMessage = "Was Here";
	private static String testUsername2 = "Lorenzo";
	private static String testMessage2 = "Testing...";
       
	public MessageBoard() {
		super();
	}
	
	public void init() {
		messages.add(new MessageBean(testUsername, testMessage));
		messages.add(new MessageBean(testUsername2, testMessage2));
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setAttribute("message", messages);
        request.getRequestDispatcher("messages.jsp").forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();	
		RegisterUser user = (RegisterUser) session.getAttribute("username");	
		String name = user.getUsername();
		String message = request.getParameter("message");
		messages.add(new MessageBean(name, message));
		if (message == null) {
			response.sendError(400, "Missing Message");
		}
		else {
		request.setAttribute("messages", messages);
		request.getRequestDispatcher("messages.jsp").forward(request, response);
		}

	}
}