package unex.java; 

import java.util.ArrayList;
import java.util.HashMap;

public class ValidatedUsers {

		private static ArrayList<RegisterUser> listOfValidUsers = new ArrayList<>();
		private static HashMap<String, ArrayList<RegisterUser> > mapOfValidUsers = new HashMap<>();
		private static String validUsername = "";
		private static String validPassword = "";
		private static String validFullname = "";
		
		private static RegisterUser user; 
		

		public ValidatedUsers() {
			user = new RegisterUser(validUsername, validPassword, validFullname);
		}
		
		public static ArrayList<RegisterUser> add(RegisterUser user) {
			listOfValidUsers.add(user);
			return listOfValidUsers;
		}
		public static HashMap<String, ArrayList<RegisterUser>> addMap(RegisterUser user) {
			mapOfValidUsers.put(validUsername, listOfValidUsers);
			return mapOfValidUsers;
		}
		
		public String getValidUsername() {
			return validUsername;
		}

		public ArrayList<RegisterUser> getListOfValidUsers() {
			return listOfValidUsers;
		}

		public static HashMap<String, ArrayList<RegisterUser>> getMapOfValidUsers() {
			return mapOfValidUsers;
		}

		public static HashMap<String, ArrayList<RegisterUser>> addMap(String validateUsername,
				ArrayList<RegisterUser> validatingUserList) {
		return mapOfValidUsers;
		}

		public static String getValidPassword() {
			return validPassword;
		}

		public static void setValidPassword(String validPassword) {
			ValidatedUsers.validPassword = validPassword;
		}

		public static RegisterUser getUser() {
			return user;
		}

		public static void setUser(RegisterUser user) {
			ValidatedUsers.user = user;
		}
	
}
