package unex.java;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

// * Developer: Colin Ilgen
// * Servlet implementation class LoginServlet
// * The Login Servlet validates the new User Account from RegisterServlet and redirects request to Message Board.

@WebServlet("/Login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	private String validateFullname;
	private String validateUsername;
	private String validatePassword; 
	
	private static RegisterUser validatingUser;
	private static ArrayList<RegisterUser> validatingUserList = new ArrayList<>();
	private static HashMap<String, ArrayList<RegisterUser> > validatingUserMap = new HashMap<>(); 

	public LoginServlet() {
		super();
	}

	public void init() {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		validateFullname = request.getParameter("fullname");
		validateUsername = request.getParameter("username");
		validatePassword = request.getParameter("password");
		
		if (validateUsername == null) {
			response.sendError(401, "Missing Password");
		}
		if (validatePassword == null) {
			response.sendError(401, "MissingPassword");
		}
		
		if (validateUsername != null && validatePassword != null) {
			
		HttpSession session = request.getSession();
		
        validatingUser = new RegisterUser(validateFullname, validateUsername, validatePassword);
        validatingUserList = ValidatedUsers.add(validatingUser);
		validatingUserMap = ValidatedUsers.addMap(validateUsername, validatingUserList);
		
      	if (validatingUserMap.equals(ValidatedUsers.getMapOfValidUsers()) ) {
			    session.setAttribute("username", validatingUser);
				session.setAttribute("password", validatingUser);
				session.setAttribute("fullname", validatingUser);
      	}
		response.sendRedirect("MessageBoard");
		return;
		} 
}
}