package unex.java;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Developer: Colin  Ilgen
 * Servlet implementation class RegisterServlet
 * The RegisterServlet creates a new User object when a user creates an account to Login for the first time.
 * That user object is then stored in a HashMap<String, ArrayList<UserRegister>>(); and then this HashMap is then checked by the LoginServlet for account verification.
 * If the hashmap list objects don't(!) match the logged in client creates a new account and parameters are forwarded to the Message Board.
 */
@WebServlet("/Register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	private String registrationFullname;
    private String registrationUsername;
    private String registrationPassword;
    
    private static String registeringUsername; 
    private static RegisterUser registeringUser;  
	private static ArrayList<RegisterUser> registeringUserList = new ArrayList<>();
	private static HashMap<String, ArrayList<RegisterUser> > registeringUserMap = new HashMap<>();
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
    }

	public void init() {
	}
    
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		
		registrationFullname = request.getParameter("fullname");
		registrationUsername = request.getParameter("username");
		registrationPassword = request.getParameter("password");

		if (registrationFullname == null) {
			response.sendError(401, "Missing Fullname");
		}
		if (registrationUsername == null) {
			response.sendError(401, "Missing Username");
		}
		if (registrationPassword == null) {
			response.sendError(401, "MissingPassword");
		}		
		
		registeringUser = new RegisterUser(registrationFullname, registrationUsername, registrationPassword);
		registeringUserList = ValidatedUsers.add(registeringUser);
		registeringUserMap = ValidatedUsers.addMap(registeringUser);
		
		//comparing newly registered user map to validated user map, if they match then proceed to message board
		
		if (registeringUserMap.equals(ValidatedUsers.getMapOfValidUsers()) ){
		   
		        session.setAttribute("username", registeringUser);
				session.setAttribute("password", registeringUser);
				session.setAttribute("fullname", registeringUser);
				response.sendRedirect("MessageBoard"); 
		}
	}

	public static String getRegisteringUsername() {
		return registeringUsername;
	}

	public static ArrayList<RegisterUser> getRegisteringUserList() {
		return registeringUserList;
	}

}