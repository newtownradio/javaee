/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hungrysquirrel;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author colinilgen
 */
public class Squirrel implements Movable  {
    
    /*
    You must define the Squirrel class.
    The squirrel is represented by the “@” symbol in the maze.
    It is able to move up, down, left and right. 
    The initial location of the squirrel is determined by the user.
    The program must prompt the user to enter the starting row and column of the squirrel.
    The squirrel cannot move to where there is a wall (i.e. ‘*’).
    Once the squirrel moves over a nut, it eats the nut and collects points. 
    Each type of nut carries a different point.
    */
   
   private int nutCounter; // counter the total number of nuts eaten thus far.
   private int points; 
   private int pointsCollected;
   private int horizontal; 
   private int vertical;
   Iterator <ArrayList<Character>> it;
   private Scanner input1;
   private Scanner input2;
   private int firstNumber; 
   private int secondNumber; 
   HashMap <ArrayList<Character>, Integer [][]> result;
   HashMap <ArrayList<Character>, Integer[][]> mapper;
   HashMap <ArrayList<Character>, Integer[][]> mapperUpdate; 
   Integer mapperValue; 
   Integer horizontalConversion;
   Integer verticalConversion;
   Integer[][] squirrelList;
   Integer [][] squirrelListUpdate; 
   Character Squirrel = '@'; 
   ArrayList<Character> squirrelObjects; 
   Character Almond = 'A';
   Character Peanut = 'P';
   Character Wall = '*';
   Character EmptySpace = ' ';
   Character Nut = '&';
   
   
   
// CONSTRUCTOR   public Squirrel(); intialize 
   public Squirrel()
   {
   squirrelObjects = new ArrayList<>();
   squirrelObjects.add(Squirrel); 
   squirrelObjects.add(Nut);
   squirrelObjects.add(Almond);
   squirrelObjects.add(Peanut); 
   squirrelObjects.add(Wall);
   squirrelObjects.add(EmptySpace);
   
   squirrelList = new Integer[20][50];
   }
    
 
    public void create() 
    {
    input1 = new Scanner(System.in);
    System.out.println("Enter the horizontal coordinate of the Squirrel as a single digit between 0 and 20 ");
    while(!input1.hasNextInt()) {
    firstNumber = input1.nextInt();
    if (firstNumber < 0 | firstNumber > 20) {
        System.out.println("That is not a valid Horizontal position. Please try again.");
    }
    else {
    horizontal = input1.nextInt();
    }
    }
    System.out.println("Enter the vertical coordinate as a single digit between 0 and 50 ");
    input2 = new Scanner(System.in);
    while (!input2.hasNextInt()) {
    secondNumber = input2.nextInt();
    if (secondNumber < 0 | secondNumber > 50) {
         System.out.println("Sorry that is not a valid Vertical position. Please try again.");
    }
    else {
    vertical = input1.nextInt(); 
    }
    } 
    horizontalConversion = (Integer)horizontal; 
    verticalConversion = (Integer)vertical; 
    squirrelListUpdate = new Integer[horizontalConversion][verticalConversion];
    mapperUpdate = new HashMap<>();
    mapperUpdate.put(squirrelObjects, squirrelListUpdate);
    }
    
    
     public void Move(String direction) {
        
        while(it.hasNext())
        {
            it.next(); 
          if (it.equals(' '))      
        {
        System.out.println("You landed on an empty space.");
        break; 
        }
           result.put(squirrelObjects, squirrelListUpdate);
        }
        
        while (it.hasNext())
        {
          it.next();
        if (it.equals('A')) {
            it.remove();
        System.out.println("You landed on an Almond");
        System.out.println("points " + points + "total points " + pointsCollected);
        points = 5; 
        pointsCollected =+5; 
        nutCounter ++;
        break; 
        }
        }
        
        while (it.hasNext())
        {
           it.next();       
        if (it.equals('P'))
            it.remove();
        {
        System.out.println("You landed on a PEANUT");
        System.out.println("points " + points + "total points " + pointsCollected);
        pointsCollected =+10;
        points = 10; 
        nutCounter ++; 
        break; 
        } 
        }
        
        while (it.hasNext())
        {
            it.next();
        if (it.equals('*')) 
        {
        System.out.println("Nice try: you hit a wall :(");
        break; 
        }    
        }
}
}
  