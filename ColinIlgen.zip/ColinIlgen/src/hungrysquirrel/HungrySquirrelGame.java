/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hungrysquirrel;

import java.io.FileNotFoundException;

/**
 *
 * @author colinilgen
 */
public class HungrySquirrelGame {
    
    
    public static void main(String[] args) throws FileNotFoundException, Exception {
     
      Maze object1 = new Maze();
      
      object1.create("Maze.txt");    
      
      Squirrel object2 = new Squirrel(); 
      object2.create();
      
      Nut[] nutArray = new Peanut[5];
      
      Maze x = new Maze();
      x.create("Maze.txt");
      
      
      

       
    }
}
   /*
1.	Call the create method of the Maze class to create the maze.
2.	Instantiate a squirrel object. This creates the squirrel and  puts the squirrel in the maze based on the user input.
3.	Instantiate an array of Nut objects and determine and create the type of nuts (almond or peanut).
4.	Display the maze with all the entities created.
5.	Accept user input to move the squirrel.
6.	For every move the full maze with all the entities should be displayed.
7.	Every time the squirrel collects a nut, a message must be output displaying the points collected for the new nut and total points collected thus far.
!!! Squirrel ate Almond and gained 5 points (Total 15 points) !!! 

8.	Once the squirrel collects all the nuts, a message must be displayed and the game is over.
“Squirrel successfully collected all the nuts. Total points 30.”
“Thank you for playing this game”

*/
