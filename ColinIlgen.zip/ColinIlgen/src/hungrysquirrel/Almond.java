/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hungrysquirrel;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author colinilgen
 */
public class Almond extends Nut {
    // Almond is a type of a Nut .  
    // An almond is represented by the character symbol ‘A’ in the maze.  
    //An almond carries 5 nutritional points; 
    // therefore, when the squirrel eats an almond, it gains 5 points.
    private final int ALMOND_NUTRITION_POINTS; 
    int currentNumberOfAlmonds;  
    int almondHorizonalCoordinate; 
    int almondVerticalCoordinate; 
    Character Almond; 
    HashMap<ArrayList<Character>, Integer [][]> almondMap;
    ArrayList<Character> almonds; 
    Integer[][] almondLocations; 
 
     
    public Almond(){
       super(objects, nutList);
       Almond = 'A';
       ALMOND_NUTRITION_POINTS =+ 5;  
    }
    
    
    @Override
    public void create() {
        
    }
}

