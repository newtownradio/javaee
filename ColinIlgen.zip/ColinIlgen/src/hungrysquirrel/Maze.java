/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hungrysquirrel;

import java.io.File;
import java.io.PrintWriter;
import static java.lang.System.in;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

/**
 *
 * @author colinilgen
 */
public class Maze {
    /* 
    You must define the Maze class. 
    The maze is a 20 x 50 rectangular area represented by a 2-dimensional Entity array.
    The walls in the maze are represented by ‘*’ and available positions by blank space. 
    The maze structure is read from a text file “Maze.txt” 
    (The Maze.txt will be provided to you).
    A squirrel is able to freely move in blank spaces in the maze.
    */
    
    Integer mazeRows; 
    Integer mazeColumns;
    public PrintWriter out;
    public String outputFile = "MAZE.txt";
    char wall;
    Character blankSpace;
    Character Squirrel = '@';
    Character Almond = 'A';
    Character Peanut = 'P'; 
    Character Wall = '*';
    Character emptySpace = ' ';
    Scanner in;
    public static HashMap<ArrayList<Character>, Integer [][]> mazeMap;
    public String nameOfMazeFile = "Maze.txt"; 
    public String inputValue;
    ArrayList<Character> mazeSymbols; 
    Integer [][] mazeEntityList;
    Set<HashMap.Entry<ArrayList<Character>, Integer[][]>> entrySet;
  
    public Maze() {
         mazeSymbols = new ArrayList<>();
         mazeSymbols.add(Squirrel); 
         mazeSymbols.add(Almond);
         mazeSymbols.add(Peanut); 
         mazeSymbols.add(Wall);
         mazeSymbols.add(emptySpace);
         mazeEntityList = new Integer[20][50];  
   }
      
    
    @SuppressWarnings("UseSpecificCatch")
    public void create(String nameOfMazeFile) 
    {   
    {
        nameOfMazeFile = "Maze.txt";
        File mazeFile = new File("Maze.txt"); 
        in = new Scanner(nameOfMazeFile);
    }
    while (entrySet != null){
    entrySet = mazeMap.entrySet();
    Iterator<HashMap.Entry<ArrayList<Character>, Integer[][]>> i;
        i = entrySet.iterator();
    while(i.hasNext()){
    HashMap.Entry<ArrayList<Character>, Integer[][]> element = i.next();
    System.out.println("Key: "+element.getKey()+" ,value: "+element.getValue());
    }
      in.close();  
    }
    }
    
    public static void display()
    {
      
      mazeMap.entrySet().forEach(System.out::println);
    }
    
    public static boolean available(int row, int col)
    {
        
        return false; 
    }
}

    
    

