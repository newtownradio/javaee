/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hungrysquirrel;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

/**
 *
 * @author colinilgen
 */
public abstract class Nut extends Entity {
    
    /*
    Nut is an abstract super class that is inherited from Entity super class. 
    There are two types of nuts available: Almond and Peanut. 
    When a squirrel eats a nut, it’ll gain points. 
    Once a nut is eaten, it should disappear from the maze. 
    There are total of 5 nuts created. 
    The nuts locations are created randomly in the maze and have to be placed in a valid location in the maze, meaning that a nut cannot be put in a position occupied by a wall (*), a squirrel (@) or a previously created nut.
    The number of peanuts / almonds are based on a random 50% chance.
    */
    ArrayList<Character> emptySpace;
    ArrayList<Character> Squirrel;
    private final int TOTAL_NUTS = 5;
    int randomNumberOfAlmonds; 
    int randomNumberOfPeanuts; 
    int randomAlmondLocationX; 
    int randomAlmondLocationY;
    int randomPeanutLocationX; 
    int randomPeanutLocationY; 
    HashMap<ArrayList<Character>, Integer [][]> nutMap;   
    Random r; 
    int[] twoRandomNumbers; 
    int count; 
    static ArrayList<Character> objects; 
    static ArrayList<Character> almond;
    static ArrayList<Character> peanut;
    static Integer [][] nutList;
    Integer randomLocationAlmondXConversion;
    Integer randomLocationYAlmondConversion; 
    Integer randomLocationPeanutXConversion;
    Integer randomLocationPeanutYConversion; 
      
   
  
    public Nut() {
    r = new Random();
    twoRandomNumbers = r.ints(2, 0, 6).toArray(); 
    randomNumberOfAlmonds = r.ints(1, 0, 6).findFirst().getAsInt();
    randomNumberOfPeanuts = r.ints(2, 0, 6).findFirst().getAsInt(); 
    
    }
   
    @Override
    public abstract void create();
    {
    if (Squirrel.equals(emptySpace));
    count =0;
    {
    do {     
    randomAlmondLocationX = r.nextInt(20) + 1;
    randomLocationAlmondXConversion = (Integer)randomAlmondLocationX;
    randomAlmondLocationY = r.nextInt(50) + 1;  
    randomLocationYAlmondConversion = (Integer)randomAlmondLocationY; 
    nutList=  new Integer[randomLocationAlmondXConversion][randomLocationYAlmondConversion];
    nutMap = new HashMap<>();
    nutMap.put(almond, nutList);
    count++;     
    }
    while (count < randomNumberOfAlmonds);
    }
    do {    
    randomPeanutLocationX = r.nextInt(20) + 1;
    randomLocationPeanutXConversion = (Integer)randomPeanutLocationX; 
    randomPeanutLocationY = r.nextInt(50) + 1;
    randomLocationPeanutYConversion = (Integer) randomPeanutLocationY; 
    nutMap.put(peanut, nutList);
    count++;     
    }
    while (count < randomNumberOfPeanuts);
    }
    
}
        
