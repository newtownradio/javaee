/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hungrysquirrel;

import static hungrysquirrel.Nut.objects;
import java.util.ArrayList;

/**
 *
 * @author colinilgen
 */
public class Peanut extends Nut {
    //Peanut is a type of a Nut. 
    //A peanut is represented by the character symbol ‘P’ in the maze.  
    // A peanut carries 10 nutritional points; 
    // therefore, when the squirrel eats a peanut, it gains 10 points.
    int PEANUT_NUTRITION_POINTS;
    Character Peanut;
    ArrayList<Character> peanutList;
    Integer [][] peanutLocations;
    
    
    public Peanut() {
        super(objects, nutList);
        Peanut = 'P';
        PEANUT_NUTRITION_POINTS =+ 10; 
    }
    
    @Override
    public void create() {
    
}
}
