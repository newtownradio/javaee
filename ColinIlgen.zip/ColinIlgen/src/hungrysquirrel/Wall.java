/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hungrysquirrel;

import static hungrysquirrel.Entity.symbol;
import java.util.ArrayList;

/**
 *
 * @author colinilgen
 */
public abstract class Wall extends Entity {
    Character Wall; 
    ArrayList<Character> wallObjects; 
    Integer [][] wallList; 
   
    
   public Wall() {   
       Wall = '*';
   }
    
}