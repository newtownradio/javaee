/*   row = [0];

 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hungrysquirrel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author colinilgen
 */
public abstract class Entity
{
    public static ArrayList<Character> symbol;
    ArrayList<Character> direction; 
    private final Character Nut = '&';
    static Character Squirrel = '@';
    private final Character Almond = 'A'; 
    private final Character Peanut = 'P';
    private final Character Wall = '*';
    private final Character EmptySpace = ' '; 
    public static HashMap<ArrayList<Character>, Integer [][]> entityMap;
    private static Integer [][] entityList;
    static Integer [][] entityListUpdated;
    Integer entityKey;
    Integer entityValue; 
    private Random randomNumber;  
    Integer  newKey; 
    Integer  newValue; 
    Character up;
    Character down; 
    Character left; 
    Character right; 
    Integer [][] entityListMovesUp; 
    Integer [][] entityListMovesDown; 
    Integer [][] entityListMovesLeft; 
    Integer [][] entityListMovesRight; 
    Character upCharacter;
    Character downCharacter; 
    Character leftCharacter; 
    Character rightCharacter; 
    Character squirrelSymbol;
    ArrayList<Character> squirrelMoves; 
    
    
   public Entity() {    
   symbol = new ArrayList<>();
   symbol.add(Squirrel); 
   symbol.add(Nut);
   symbol.add(Almond);
   symbol.add(Peanut); 
   symbol.add(Wall);
   symbol.add(EmptySpace);
   entityList = new Integer[20][50];
   entityMap.put(symbol, entityList);
   }
  
    public abstract void create();
    static {
    }
  
    public void put(int newRow, int newColumn){        
    for(int i=0;i<21;i++)
    {
       newKey = randomNumber.nextInt(); 
       newRow = newKey; 
    } 
    for(int j=0;j<51; j++)
    {
        newValue = randomNumber.nextInt(); 
        newColumn = newValue; 
    } 
    entityListUpdated = new Integer[newRow][newColumn];
    entityMap.put(symbol,entityListUpdated);
    entityMap.entrySet().forEach(System.out::println);
    }
    
    public void Move(Character direction)
    {
        squirrelSymbol = symbol.get(0);
        while (squirrelSymbol.equals(' ')) 
    { 
        Scanner in = new Scanner(System.in);
        System.out.println("Enter a Squirrel direction: w for up, x for down, a for left, d for right. Must be all in lowercase letters. ");
        String authorizeDirection = in.next();
        if (authorizeDirection.equals("w")) {
           char upChar = authorizeDirection.charAt(0);
           if (upChar == 'w')
           {
           upCharacter = upChar; 
           newKey += 1;
           entityListMovesUp = new Integer[newKey][newValue];
           squirrelMoves = new ArrayList<>();
           squirrelMoves.add(squirrelSymbol);
           entityMap.put(squirrelMoves, entityListMovesUp);
           entityMap.entrySet().forEach(System.out::println);
        }
        if (authorizeDirection.equals("x")) {
            char downChar = authorizeDirection.charAt(0);
            if (downChar == 'x')
            {
           downCharacter = downChar; 
           newValue -= 1; 
           entityListMovesDown =new Integer [newKey][newValue];
           entityMap.put(squirrelMoves, entityListMovesDown);
           entityMap.entrySet().forEach(System.out::println);
            }
        }
        if (authorizeDirection.equals("a")); {
            char leftChar = authorizeDirection.charAt(0);
            if (leftChar == 'a')
            {
            leftCharacter = leftChar; 
            newKey =- 1; 
            entityListMovesLeft = new Integer [newKey][newValue];
            entityMap.put(squirrelMoves, entityListMovesLeft);  
            entityMap.entrySet().forEach(System.out::println);
            }
        }
        if(authorizeDirection.equals("D")); {
            char rightChar = authorizeDirection.charAt(0);
            if (rightChar == 'd')
            {
            rightCharacter = rightChar; 
            newValue +=1;
            entityListMovesRight = new Integer [newKey][newValue];
            entityMap.put(squirrelMoves, entityListMovesRight);
            entityMap.entrySet().forEach(System.out::println);
        } 
        }
           
    }
    
    }
    }
        
    }
        
    

