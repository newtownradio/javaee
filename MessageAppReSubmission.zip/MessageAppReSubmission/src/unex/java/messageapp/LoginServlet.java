package unex.java.messageapp;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

// * Developer: Colin Ilgen
// * Servlet implementation class LoginServlet
// * The Login Servlet validates the User against a list of validatedUsers objects in a hashmap and then redirects logged in user to Message Board or throws an error if username or password is incorrect.

@WebServlet("/Login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	private static HashMap<String, User> mapOfValidUsers = new HashMap<>();
	
	public LoginServlet() {
		super();
	}

	public void init() {
		// Pay attention to usernames and passwords they are Case Sensitive 
		
		mapOfValidUsers.put("charles", new User("charles", "pass", "Charles Harless")); 
		mapOfValidUsers.put("steve", new User("steve", "apple", "Steve Jobs"));
	    mapOfValidUsers.put("bill", new User("bill", "pc", "Bill Gates"));
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		HttpSession session = request.getSession();
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		if (username == null) {
			response.sendError(401, "Missing Username");
		}
		if (password == null) {
			response.sendError(401, "MissingPassword");
		}
		
		if(mapOfValidUsers.containsKey(username)) {
			User user = mapOfValidUsers.get(username);
			if(user.checkPassword(password)) {
				session.setAttribute("username", user);
				response.sendRedirect("MessageBoard");
			} else {
				response.sendError(401, "Invalid Password");
			}
		} else {
			response.sendError(401, "Invalid Username");
		}
	}
}
				
