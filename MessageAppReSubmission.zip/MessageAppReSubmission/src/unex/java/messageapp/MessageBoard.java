/**
 * Developer: Colin Ilgen
 * Class Package & Name: unex.java.MessageBoard
 * Overall Purpose: 
   1. View current messages on the MessageBoardApp 
   2. Select to add a new message (link)
   3. Input the new message using a form 
   4. Submit the form 
   5. Display all current messages including new message
 */

package unex.java.messageapp;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/* Developer: Colin Ilgen
* Servlet implementation class MessageBoard
 */

@WebServlet("/MessageBoard")
public class MessageBoard extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	private static ArrayList<MessageBean> messages = new ArrayList<>();
	
	// test data
	
	private static String testMessageBoardUsername = "Rich";
	private static String testMessageBoardMessage = "Was Here";
	
	private static String testMessageBoardUsername2 = "Lorenzo";
	private static String testMessageBoardMessage2 = "Howdy";
	
	private static String testMessageBoardUsername3 = "Joaquin";
	private static String testMessageBoardMessage3 = "COOL";
	
	
	public MessageBoard() {
		super();
	}
	
	public void init() {
		messages.add(new MessageBean(testMessageBoardUsername,  testMessageBoardMessage));
		messages.add(new MessageBean(testMessageBoardUsername2, testMessageBoardMessage2));
		messages.add(new MessageBean(testMessageBoardUsername3, testMessageBoardMessage3));

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setAttribute("messages", messages);
        request.getRequestDispatcher("messages.jsp").forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();	
		User user = (User) session.getAttribute("username");	
		String name = user.getUsername();
		String message = request.getParameter("message");
		if (message == null) {
			response.sendError(400, "Missing Message");
		}
		else {
		messages.add(new MessageBean(name, message));
		request.setAttribute("messages", messages);
		request.getRequestDispatcher("messages.jsp").forward(request, response);
		}
	}

}