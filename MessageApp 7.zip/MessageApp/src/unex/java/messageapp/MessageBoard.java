/**
 * Developer: Colin Ilgen
 * Class Package & Name: unex.java.MessageBoard
 * Overall Purpose: 
   1. View current messages on the MessageBoardApp index.html welcome page
   2. Select to add a new message (link)
   3. Input the new message using a form 
   4. Submit the form 
   5. Display all current messages including new message
 */

package unex.java.messageapp;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import unex.java.messageapp.MessageBean; 
/**
 * Servlet implementation class MessageBoard
 */
@WebServlet("/MessageBoard")
public class MessageBoard extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private ArrayList<MessageBean> messages;
       
	public MessageBoard() {
		super();
	    messages = new ArrayList<MessageBean>();
	    messages.add(new MessageBean("Frank", "Hello"));
	    messages.add(new MessageBean("Tuna", "Sounds Good"));
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		out.println("<html><head><title>Message Board</title></head><body>");
		out.println("<h2>MESSAGES</h2>");
		out.println("<ul>");
		for(MessageBean c:messages) {
			out.println("<li><strong>" + c.getName() + "</strong></li>" + "<li>" + c.getMessage() + 
					"</li>" + "<br>");
		}
		out.println("</ul>");
		out.println("<hr><h4><a href='form.html'>Add Message</a></h4>");
		out.println("</body></html>");
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    String name = request.getParameter("name");
		String message = request.getParameter("message");
		
		messages.add(new MessageBean(name, message));

		doGet(request, response);
	}

}
